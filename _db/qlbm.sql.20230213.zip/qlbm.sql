-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Feb 13, 2023 at 05:26 AM
-- Server version: 5.7.25
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `qlbm`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_assignment`
--

CREATE TABLE `auth_assignment` (
  `item_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_assignment`
--

INSERT INTO `auth_assignment` (`item_name`, `user_id`, `created_at`) VALUES
('role_doankiemtra', 2, 1669961286),
('role_doankiemtra', 4, 1675390633),
('role_donvi', 2, 1669995504);

-- --------------------------------------------------------

--
-- Table structure for table `auth_item`
--

CREATE TABLE `auth_item` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `rule_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `group_code` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item`
--

INSERT INTO `auth_item` (`name`, `type`, `description`, `rule_name`, `data`, `created_at`, `updated_at`, `group_code`) VALUES
('/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/admin/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/admin/room-parent/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/admin/room-parent/bulk-delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/admin/room-parent/create', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/admin/room-parent/delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/admin/room-parent/index', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/admin/room-parent/update', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/admin/room-parent/view', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/admin/room/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/admin/room/bulk-delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/admin/room/create', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/admin/room/delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/admin/room/index', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/admin/room/update', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/admin/room/view', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/admin/thong-ke-truy-cap/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/admin/thong-ke-truy-cap/bulk-delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/admin/thong-ke-truy-cap/create', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/admin/thong-ke-truy-cap/delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/admin/thong-ke-truy-cap/index', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/admin/thong-ke-truy-cap/update', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/admin/thong-ke-truy-cap/view', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/debug/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/debug/default/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/debug/default/db-explain', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/debug/default/download-mail', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/debug/default/index', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/debug/default/toolbar', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/debug/default/view', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/debug/user/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/debug/user/reset-identity', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/debug/user/set-identity', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/doc/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/doc/test', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/gii/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/gii/default/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/gii/default/action', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/gii/default/diff', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/gii/default/index', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/gii/default/preview', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/gii/default/view', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/google-drive/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/google-drive/success', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/google-drive/test-create-folder', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/google-drive/test-setup', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/google-drive/upload', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/google-drive/upload2', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/google-drive/upload3', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/google-drive/upload4', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/gridview/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/gridview/export/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/gridview/export/download', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/gridview/grid-edited-row/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/gridview/grid-edited-row/back', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/default/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/default/index', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/doan-danh-gia/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/doan-danh-gia/bulk-delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/doan-danh-gia/create', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/doan-danh-gia/delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/doan-danh-gia/index', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/doan-danh-gia/update', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/doan-danh-gia/view', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/doc-group/*', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/doc-group/bulk-delete', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/doc-group/create', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/doc-group/delete', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/doc-group/index', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/doc-group/update', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/doc-group/view', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/doc-type/*', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/doc-type/bulk-delete', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/doc-type/create', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/doc-type/delete', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/doc-type/index', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/doc-type/update', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/doc-type/view', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/docs-iso/*', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/docs-iso/bulk-delete', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/docs-iso/create', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/docs-iso/delete', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/docs-iso/index', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/docs-iso/update', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/docs-iso/view', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/docs/*', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/docs/bulk-delete', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/docs/create', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/docs/delete', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/docs/download', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/docs/index', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/docs/update', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/docs/view', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/docss/*', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/docss/bulk-delete', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/docss/create', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/docss/delete', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/docss/index', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/docss/update', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/docss/view', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/document/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/document/bulk-delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/document/create', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/document/delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/document/download', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/document/index', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/document/update', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/document/view', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/document/view-public', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/drive/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/drive/reset-google', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/drive/upload', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/examination/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/examination/bulk-delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/examination/create', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/examination/delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/examination/index', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/examination/update', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/examination/view', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/file/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/file/create', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/file/download', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/file/upload-drive', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/file/view-drive', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/iso/*', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/iso/bulk-delete', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/iso/create', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/iso/delete', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/iso/index', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/iso/update', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/iso/view', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/phong-ban/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/phong-ban/bulk-delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/phong-ban/create', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/phong-ban/delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/phong-ban/index', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/phong-ban/update', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/phong-ban/view', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/select/*', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/select/class-group-list', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/select/get-list-room-by-name-and-parent', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/select/get-list-room-by-parent', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/select/student-list', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/select/subject-list', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/select/teacher-list', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/team-member/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/team-member/bulk-delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/team-member/create', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/team-member/delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/team-member/index', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/team-member/update', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/team-member/view', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/team-member/view-public', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/team-postion/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/team-postion/bulk-delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/team-postion/create', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/team-postion/delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/team-postion/index', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/team-postion/update', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/team-postion/view', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/template/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/template/bulk-delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/template/create', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/template/delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/template/download', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/template/index', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/template/update', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/template/view', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/working-files/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/working-files/bulk-delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/working-files/create', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/working-files/delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/working-files/index', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/working-files/update', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/working-files/view', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/working/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/working/bulk-delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/working/create', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/working/delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/working/index', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/working/index-iso', 3, NULL, NULL, NULL, 1676254159, 1676254159, NULL),
('/manage/working/update', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/manage/working/view', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/site/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/site/about', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/site/captcha', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/site/contact', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/site/error', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/site/index', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/site/login', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/site/logout', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/site/show-error', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/site/test', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/auth-item-group/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/auth-item-group/bulk-activate', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/auth-item-group/bulk-deactivate', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/auth-item-group/bulk-delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/auth-item-group/create', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/auth-item-group/delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/auth-item-group/grid-page-size', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/auth-item-group/grid-sort', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/auth-item-group/index', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/auth-item-group/toggle-attribute', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/auth-item-group/update', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/auth-item-group/view', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/auth/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/auth/captcha', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/auth/change-own-password', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/auth/confirm-email', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/auth/confirm-email-receive', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/auth/confirm-registration-email', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/auth/login', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/auth/logout', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/auth/password-recovery', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/auth/password-recovery-receive', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/auth/registration', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/permission/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/permission/bulk-activate', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/permission/bulk-deactivate', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/permission/bulk-delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/permission/create', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/permission/delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/permission/grid-page-size', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/permission/grid-sort', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/permission/index', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/permission/refresh-routes', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/permission/set-child-permissions', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/permission/set-child-routes', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/permission/toggle-attribute', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/permission/update', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/permission/view', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/role/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/role/bulk-activate', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/role/bulk-deactivate', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/role/bulk-delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/role/create', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/role/delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/role/grid-page-size', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/role/grid-sort', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/role/index', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/role/set-child-permissions', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/role/set-child-roles', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/role/toggle-attribute', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/role/update', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/role/view', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/user-permission/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/user-permission/set', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/user-permission/set-roles', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/user-visit-log/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/user-visit-log/bulk-activate', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/user-visit-log/bulk-deactivate', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/user-visit-log/bulk-delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/user-visit-log/create', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/user-visit-log/delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/user-visit-log/grid-page-size', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/user-visit-log/grid-sort', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/user-visit-log/index', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/user-visit-log/toggle-attribute', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/user-visit-log/update', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/user-visit-log/view', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/user/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/user/bulk-activate', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/user/bulk-deactivate', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/user/bulk-delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/user/change-password', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/user/create', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/user/delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/user/grid-page-size', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/user/grid-sort', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/user/index', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/user/toggle-attribute', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/user/update', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user-management/user/view', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/auth-item-group/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/auth-item-group/bulk-activate', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/auth-item-group/bulk-deactivate', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/auth-item-group/bulk-delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/auth-item-group/create', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/auth-item-group/delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/auth-item-group/grid-page-size', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/auth-item-group/grid-sort', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/auth-item-group/index', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/auth-item-group/toggle-attribute', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/auth-item-group/update', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/auth-item-group/view', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/auth/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/auth/captcha', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/auth/change-own-password', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/auth/confirm-email', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/auth/confirm-email-receive', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/auth/confirm-registration-email', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/auth/login', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/auth/logout', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/auth/password-recovery', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/auth/password-recovery-receive', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/auth/registration', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/permission/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/permission/bulk-activate', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/permission/bulk-deactivate', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/permission/bulk-delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/permission/create', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/permission/delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/permission/grid-page-size', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/permission/grid-sort', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/permission/index', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/permission/refresh-routes', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/permission/set-child-permissions', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/permission/set-child-routes', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/permission/toggle-attribute', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/permission/update', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/permission/view', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/role/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/role/bulk-activate', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/role/bulk-deactivate', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/role/bulk-delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/role/create', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/role/delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/role/grid-page-size', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/role/grid-sort', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/role/index', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/role/set-child-permissions', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/role/set-child-roles', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/role/toggle-attribute', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/role/update', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/role/view', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/user-permission/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/user-permission/set', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/user-permission/set-roles', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/user-visit-log/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/user-visit-log/bulk-activate', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/user-visit-log/bulk-deactivate', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/user-visit-log/bulk-delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/user-visit-log/create', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/user-visit-log/delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/user-visit-log/grid-page-size', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/user-visit-log/grid-sort', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/user-visit-log/index', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/user-visit-log/toggle-attribute', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/user-visit-log/update', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/user-visit-log/view', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/user/*', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/user/bulk-activate', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/user/bulk-deactivate', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/user/bulk-delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/user/change-password', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/user/create', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/user/delete', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/user/grid-page-size', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/user/grid-sort', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/user/index', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/user/toggle-attribute', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/user/update', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('/user/user/view', 3, NULL, NULL, NULL, 1669959356, 1669959356, NULL),
('per_admin', 2, 'Quyền admin', NULL, NULL, 1669959594, 1669959594, 'userCommonPermissions'),
('per_admin_kho_du_lieu', 2, 'Quyền quản lý kho dữ liệu', NULL, NULL, 1676254619, 1676254619, 'userCommonPermissions'),
('per_doankiemtra', 2, 'Quyền truy cập trang cho đoàn đánh giá', NULL, NULL, 1669959500, 1669959684, 'userCommonPermissions'),
('per_donvi', 2, 'Quyền truy cập đơn vị kiểm tra', NULL, NULL, 1669959262, 1669959262, 'userCommonPermissions'),
('per_macdinh', 2, 'Quyền mặc định', NULL, NULL, 1669959745, 1669959745, 'userManagement'),
('per_view_kho_du_lieu', 2, 'Quyền tra cứu kho dữ liệu', NULL, NULL, 1676254515, 1676254515, 'userCommonPermissions'),
('role_admin', 1, 'Quản trị', NULL, NULL, 1669959225, 1669959225, NULL),
('role_doankiemtra', 1, 'Đoàn kiểm tra', NULL, NULL, 1669959239, 1669959239, NULL),
('role_donvi', 1, 'Đơn vị kiểm tra', NULL, NULL, 1669959233, 1669959233, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `auth_item_child`
--

CREATE TABLE `auth_item_child` (
  `parent` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `child` varchar(64) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item_child`
--

INSERT INTO `auth_item_child` (`parent`, `child`) VALUES
('per_admin', '/admin/*'),
('per_admin', '/manage/*'),
('per_doankiemtra', '/manage/doan-danh-gia/*'),
('per_admin_kho_du_lieu', '/manage/docs-iso/*'),
('per_view_kho_du_lieu', '/manage/docs-iso/index'),
('per_view_kho_du_lieu', '/manage/docs-iso/view'),
('per_admin_kho_du_lieu', '/manage/docs/*'),
('per_view_kho_du_lieu', '/manage/docs/download'),
('per_view_kho_du_lieu', '/manage/docs/index'),
('per_view_kho_du_lieu', '/manage/docs/view'),
('per_donvi', '/manage/document/*'),
('per_doankiemtra', '/manage/document/download'),
('per_doankiemtra', '/manage/document/view'),
('per_donvi', '/manage/file/download'),
('per_donvi', '/manage/phong-ban/*'),
('per_doankiemtra', '/manage/working-files/create'),
('per_doankiemtra', '/manage/working-files/update'),
('per_macdinh', '/site/index'),
('per_admin', '/user-management/*'),
('per_macdinh', '/user/auth/change-own-password'),
('per_macdinh', '/user/auth/login'),
('per_macdinh', '/user/auth/logout'),
('role_admin', 'per_admin'),
('role_doankiemtra', 'per_doankiemtra'),
('role_donvi', 'per_donvi'),
('role_admin', 'per_macdinh'),
('role_doankiemtra', 'per_macdinh'),
('role_donvi', 'per_macdinh'),
('role_doankiemtra', 'per_view_kho_du_lieu'),
('role_donvi', 'per_view_kho_du_lieu');

-- --------------------------------------------------------

--
-- Table structure for table `auth_item_group`
--

CREATE TABLE `auth_item_group` (
  `code` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item_group`
--

INSERT INTO `auth_item_group` (`code`, `name`, `created_at`, `updated_at`) VALUES
('userCommonPermissions', 'User common permission', 1627264805, 1627264805),
('userManagement', 'User management', 1627264805, 1627264805);

-- --------------------------------------------------------

--
-- Table structure for table `auth_rule`
--

CREATE TABLE `auth_rule` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bm_docgroup`
--

CREATE TABLE `bm_docgroup` (
  `id` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `id_iso` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bm_docgroup`
--

INSERT INTO `bm_docgroup` (`id`, `name`, `id_iso`, `date_created`, `user_created`) VALUES
(2, 'Loại 1', 1, '2022-12-22 20:30:26', 1),
(3, 'Loại 2', 2, '2022-12-22 20:30:33', 1);

-- --------------------------------------------------------

--
-- Table structure for table `bm_docs`
--

CREATE TABLE `bm_docs` (
  `id` int(11) NOT NULL,
  `id_type` int(11) NOT NULL,
  `id_group` int(11) NOT NULL,
  `code` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `doc_name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `doc_ext` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `doc_url` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `summary` text COLLATE utf8_unicode_ci,
  `user_created` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `doc_no` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `doc_summary` text COLLATE utf8_unicode_ci,
  `doc_date` datetime DEFAULT NULL,
  `doc_sign` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bm_docs`
--

INSERT INTO `bm_docs` (`id`, `id_type`, `id_group`, `code`, `doc_name`, `doc_ext`, `doc_url`, `summary`, `user_created`, `date_created`, `doc_no`, `doc_summary`, `doc_date`, `doc_sign`) VALUES
(2, 1, 2, '656cf44aab61589033e93a0136f31dce', 'rpInHoaDon.pdf', 'pdf', '', '', 1, '2022-12-22 22:20:55', '100/DHTV', 'trích yếu văn bản', '2023-02-01 00:00:00', ''),
(3, 1, 3, '7ff7a64a6e7820f4cf940de06e7c183b', NULL, NULL, 'http://aaaaaaaaa.com', '', 1, '2022-12-23 16:44:01', '', '', NULL, '');

-- --------------------------------------------------------

--
-- Table structure for table `bm_doctype`
--

CREATE TABLE `bm_doctype` (
  `id` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bm_doctype`
--

INSERT INTO `bm_doctype` (`id`, `name`, `date_created`, `user_created`) VALUES
(1, 'Báo cáo', '2022-12-22 19:23:15', 1);

-- --------------------------------------------------------

--
-- Table structure for table `bm_document`
--

CREATE TABLE `bm_document` (
  `id` int(11) NOT NULL,
  `id_working` int(11) NOT NULL,
  `document_name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `document_url` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `document_type` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `summary` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bm_document`
--

INSERT INTO `bm_document` (`id`, `id_working`, `document_name`, `document_url`, `document_type`, `summary`, `date_created`, `user_created`) VALUES
(1, 1, 'Invoice_Template_01.docx', '', 'docx', '', '2022-12-17 20:04:38', 1),
(2, 3, 'grid-export (1).pdf', 'àadsfasfsaf', 'pdf', 'xx', '2023-02-11 07:18:43', 1),
(3, 3, 'grid-export.html', 'àadsfasfsaf', 'html', 'xx', '2023-02-11 13:04:04', 1),
(4, 3, 'grid-export (1).pdf', '', 'pdf', '', '2023-02-11 13:04:17', 1),
(5, 3, 'd758d920c79339acfbe497a20977080d (5).docx', 'àadsfasfsaf', 'docx', '', '2023-02-11 13:04:25', 1);

-- --------------------------------------------------------

--
-- Table structure for table `bm_examination`
--

CREATE TABLE `bm_examination` (
  `id` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `summary` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  `id_iso` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bm_examination`
--

INSERT INTO `bm_examination` (`id`, `name`, `summary`, `date_created`, `user_created`, `id_iso`) VALUES
(1, 'kỳ kiểm tra 2022', '', '2022-12-17 20:02:51', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `bm_iso`
--

CREATE TABLE `bm_iso` (
  `id` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `summary` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bm_iso`
--

INSERT INTO `bm_iso` (`id`, `name`, `summary`, `date_created`, `user_created`) VALUES
(1, 'Tiêu chuẩn ISO 1', 'Tiêu chuẩn ISO 1', '2022-12-22 09:18:24', 1),
(2, 'Tiêu chuẩn ISO 2', 'Tiêu chuẩn ISO 2', '2022-12-22 09:48:59', 1);

-- --------------------------------------------------------

--
-- Table structure for table `bm_team_member`
--

CREATE TABLE `bm_team_member` (
  `id` int(11) NOT NULL,
  `id_working` int(11) NOT NULL,
  `id_position` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `summary` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bm_team_member`
--

INSERT INTO `bm_team_member` (`id`, `id_working`, `id_position`, `id_user`, `summary`, `date_created`, `user_created`) VALUES
(1, 1, 1, 2, '', '2022-12-17 20:04:18', 1),
(2, 1, 2, 4, '', '2022-12-17 20:04:26', 1),
(5, 3, 1, 4, '', '2023-02-11 07:13:06', 1),
(6, 3, 2, 2, '', '2023-02-11 07:13:15', 1),
(7, 3, 1, 2, 'xx', '2023-02-11 13:17:05', 1),
(8, 3, 2, 5, '', '2023-02-11 22:19:37', 1),
(9, 3, 2, 1, '', '2023-02-11 22:33:23', 1);

-- --------------------------------------------------------

--
-- Table structure for table `bm_team_postion`
--

CREATE TABLE `bm_team_postion` (
  `id` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `summary` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bm_team_postion`
--

INSERT INTO `bm_team_postion` (`id`, `name`, `summary`, `date_created`, `user_created`) VALUES
(1, 'Trưởng đoàn', 'test', '2022-11-17 15:03:19', 1),
(2, 'Thành viên', '', '2022-11-21 13:24:18', 1);

-- --------------------------------------------------------

--
-- Table structure for table `bm_template`
--

CREATE TABLE `bm_template` (
  `id` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `summary` text COLLATE utf8_unicode_ci,
  `code` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_default` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bm_template`
--

INSERT INTO `bm_template` (`id`, `name`, `summary`, `code`, `file_name`, `is_default`, `date_created`, `user_created`) VALUES
(1, 'mẫu 1', '', 'd758d920c79339acfbe497a20977080d', 'd758d920c79339acfbe497a20977080d.docx', 0, '2022-12-17 20:02:21', 1),
(2, 'mẫu 2', '', '618053f1d94f5548c402e8dfbe3481ef', '618053f1d94f5548c402e8dfbe3481ef.docx', 0, '2022-12-17 20:02:31', 1);

-- --------------------------------------------------------

--
-- Table structure for table `bm_working`
--

CREATE TABLE `bm_working` (
  `id` int(11) NOT NULL,
  `code` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id_examination` int(11) NOT NULL,
  `id_room` int(11) NOT NULL,
  `date_exam` date DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  `summary` text COLLATE utf8_unicode_ci,
  `id_template_group` int(11) DEFAULT NULL,
  `id_template_single` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bm_working`
--

INSERT INTO `bm_working` (`id`, `code`, `id_examination`, `id_room`, `date_exam`, `date_created`, `user_created`, `summary`, `id_template_group`, `id_template_single`) VALUES
(1, '5a169265dbd156d94bd8653b08131d08', 1, 266, '2022-12-08', '2022-12-17 20:03:14', 1, '', 1, 2),
(3, 'd78802dc8f4b5e236eb6833793b93359', 1, 267, '2023-02-05', '2023-02-11 07:12:53', 1, '', 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `bm_working_files`
--

CREATE TABLE `bm_working_files` (
  `id` int(11) NOT NULL,
  `id_working` int(11) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `file_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `file_type` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_url` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `shared_with` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `summary` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bm_working_files`
--

INSERT INTO `bm_working_files` (`id`, `id_working`, `id_user`, `file_name`, `file_type`, `file_url`, `shared_with`, `summary`, `date_created`, `user_created`) VALUES
(17, 1, NULL, 'd758d920c79339acfbe497a20977080d.docx', 'TYPE_BB', NULL, NULL, NULL, '2023-02-11 07:12:12', 1),
(18, 1, 2, '2_618053f1d94f5548c402e8dfbe3481ef.docx', 'TYPE_CN', NULL, NULL, NULL, '2023-02-11 07:12:12', 1),
(19, 1, 4, '4_618053f1d94f5548c402e8dfbe3481ef.docx', 'TYPE_CN', NULL, NULL, NULL, '2023-02-11 07:12:12', 1),
(20, 3, NULL, 'd758d920c79339acfbe497a20977080d.docx', 'TYPE_BB', NULL, NULL, NULL, '2023-02-11 07:13:17', 1),
(21, 3, 4, '4_618053f1d94f5548c402e8dfbe3481ef.docx', 'TYPE_CN', NULL, NULL, NULL, '2023-02-11 07:13:17', 1),
(22, 3, 2, '2_618053f1d94f5548c402e8dfbe3481ef.docx', 'TYPE_CN', NULL, NULL, NULL, '2023-02-11 07:13:17', 1),
(23, 3, NULL, 'u_grid-export (1).pdf', 'TYPE_OTHER', NULL, NULL, '', '2023-02-11 12:42:20', 1);

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `id_student` int(11) NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `is_new` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `id_student`, `content`, `date`, `is_new`) VALUES
(1, 4811, 'Em đã chuyển qua lớp DA15XD, trên trang cổng thông tin sinh viên đã chuyển, nhưng trên trang khảo sát trực tuyến vẫn để DA15K em không thể khảo sát trực tuyến môn cần khảo sát được, mong thầy cô xem xét điều chỉnh lại. Em cảm ơn', '2016-05-11', 1),
(2, 779, 'nôi dung khảo sát không có dữ liệu để hoạt động\r\n', '2016-05-16', 1),
(3, 1455, 'em là Thanh Tâm - DA13LB, có những môn em đăng ký học với lớp khác, vậy những môn đó có được khảo sát không ạ? Tại em đang học môn Sở hữu trí tuệ với DA13LD, em muốn khảo sát môn này, mà sao không thấy hiện lên trên cột Môn học.', '2016-05-18', 1),
(4, 3038, 'E muốn khảo sát lại môn Mạch điện tử.', '2016-06-04', 1),
(5, 6077, 'Vấn đề bảo mật của của trang quá lỏng lẻo đề nghị thêm chức năng đổi mật khẩu cho tài khoản đánh giá khảo sát môn học hoặc thêm một số qui tắc đổi email cho phù hợp, tránh tình trạng sinh viên này có thể đánh giá hộ sinh viên khác hoặc người khác cố ý đăng nhập làm mất chất lượng của cuộc khảo sát. Thân.', '2016-06-06', 1),
(6, 6077, 'Xin chảo ban quản trị, \r\nWebsite đánh giá trực tuyến còn khá nhiều lỗi, hiện nay đa số sinh viên sử dụng điện thoại di động để lướt web và lên trang www.dbcl.tvu.edu.vn để thực hiện khảo sát cũng nằm trong số đó, tuy nhiên khi truy cập vào trang web thông qua điện thoại thì dẫn đến đường truyền chuyển hướng qua website khác Official USA Green Card...\r\nMong ban quản trị website khắc phục sớm tình trạng này.\r\nThân.', '2016-06-06', 1),
(7, 6090, 'chỉ khảo sát được 2 môn học', '2016-06-09', 1),
(8, 8538, 'Tư tưởng Hồ Chí Minh \r\nPháp luật đại cương	\r\nTiếng Khmer 2\r\nba môn này: em PHAN VĂN CƯỜNG sinh viên lớp CA15TKM . đã đánh dấu ở mục 4. Mức độ hài lòng của bạn về GV giảng dạy môn học này: là rất không hai lòng xin phép PHÒNG ĐẢM BẢO CHẤT LƯỢNG  sữa lại thành rất hài lòng', '2016-07-11', 1),
(9, 7798, 'em lỡ đánh lộn ô rât không hài lòng vì đọc nhầm , cho em hỏi làm sao đẻ khảo sát lại vậy thầy( cô).\r\n', '2016-08-16', 1),
(10, 8178, 'em bấm nhầm \"rất đồng ý\" thành \" rất không đồng ý\" nhưng nộp rồi không sửa được nữa phải làm sao ạ?', '2016-10-31', 1),
(11, 1455, 'Dạ, em là Thanh Tâm lớp DA13LB. Chuyện là môn Tố tụng Dân sự 2 lớp em học là do thầy Nguyễn Chế Linh giảng dạy ạ, không phải cô Nguyễn Thị Hoài Trâm. Nên em không biết có tiếp tục làm khao sát đối với môn này không?', '2016-12-07', 1),
(12, 2809, 'Trong danh sách khảo sát môn học, em không có học môn Thị trường giao sau & Q.chọn nhưng em có học môn Quản trị doanh nghiệp mà sao không có trong khảo sát môn học ?????????????', '2016-12-08', 1),
(13, 4240, 'em tên Trầm Quốc Đạt  MSSV 111714002  vào khảo sát trực tuyến không được', '2016-12-10', 1),
(14, 54, 'xin chao thay (co)\r\ne vừa hoàn thành xong khóa luận văn, e đc thông báo lên trang web  phòng đảm bảo chất lượng để làm khảo sát online trước khi ra trường, nhung e khong thay bieu mau danh gia mon hoc cua hoc ky I 2016-2017 z e phai lam sao?\r\n', '2016-12-16', 1),
(15, 64, 'Dear Thầy Cô,\r\nSao em không thể thực hiện khảo sát trên Web vậy.\r\nThanks thầy cô.\r\nTrân trọng!!!\r\nNguyễn Văn Tâm - DA12HH', '2016-12-16', 1),
(16, 9769, 'cho em hỏi. em còn một giáo viên dạy bộ môn xã hội học đại cương nhưng em không tìm thấy tên thầy trong phần khảo xác môn học của em. hay là chỉ khảo xác những giáo viên có trong danh sách khảo xác thôi? mong thầy cô giải đáp dùm em', '2016-12-17', 1),
(17, 9660, 'em khong thay bat ky mon hoc nao de khao sat', '2016-12-18', 1),
(18, 10698, 'em khảo sát lon 1 môn em xin khảo sát lại em xin loi', '2016-12-19', 1),
(19, 6354, 'Môn Dân số học của em là cô Nguyễn Thị Hồng Tuyến, không phái thầy Dũng ạ, kính mong Quý Thầy (Cô) chỉnh sửa lại giúp em.', '2016-12-22', 1),
(20, 2680, 'trang chưa cập nhât môn học, không khảo sát được!', '2016-12-29', 1),
(21, 5042, 'Môn học: Kỹ năng chăm sóc khách hàng\r\nGiảng viên: Lý Thị Bé Luyễn', '2017-04-18', 1),
(22, 10588, 'KHẢO SÁT HỌC KỲ II 2016-2017\r\nKhông có dữ liệu.\r\nKHẢO SÁT ANH VĂN\r\nKhông có dữ liệu.\r\nKHẢO SÁT GDTC\r\nKhông có dữ liệu.\r\nEm không khảo sát được', '2017-05-29', 1),
(23, 10588, 'Khảo sát được cộng 8đ rèn luyện,em có cần phải đến phòng DBCL để nhận giấy xác nhận cộng điển không ạ?', '2017-05-29', 1),
(24, 10572, 'KHẢO SÁT HỌC KỲ II 2016-2017\r\nKhông có dữ liệu.\r\nKHẢO SÁT ANH VĂN\r\nKhông có dữ liệu.\r\nKHẢO SÁT GDTC\r\nKhông có dữ liệu\r\nVào Khảo sát môn học, tất cả đều không có dữ liệu. Em không thẻ khảo sát. Sau khi em khảo sát,có cần phải đến phòng DBCL để nhận giấy xác nhận để được cộng điểm rèn luyện không ạ?', '2017-05-29', 1),
(25, 8523, 'môn Tiếng Việt và phương pháp dạy học Tiếng Việt 2 của lớp CA15TH do cô Nguyễn Thị Ngọc Hiếu đứng lớp giảng dạy không phải là thầy Phạm Vũ Phong, em nhờ Phòng kiểm tra lại.', '2017-06-08', 1),
(26, 9467, 'Em tên Thạch Minh Mẫn lớp CA16TKM nhưng trên đây mã lớp lại ghi là CA16QV.Cho em hỏi là mã lớp ghi sai khảo sát có sao không ạ?', '2017-07-04', 1),
(27, 2812, 'Môn Thực hành hàn của lớp DA14CKC gồm 2 nhóm 1 là của thầy Dương Minh Hùng và nhóm 2 là của thầy Tăng Tấn Minh em đã nhờ sữa rồi nhưng còn sai nhờ phòng đảm bảo chất lượng sữa lại.', '2017-12-13', 1),
(28, 13091, 'Dạ tài khoản của em sau khi đăng nhập vào thì không có dữ liệu khảo sát môn học ạ. Xin phòng khảo sát xem lại dùm em ạ.', '2017-12-13', 1),
(29, 11446, 'sao em không khảo sát dược\r\n', '2017-12-14', 1),
(30, 12803, 'sao không thay đổi số điện thoại được vậy', '2017-12-14', 1),
(31, 11446, 'e khong khao sat duoc', '2017-12-15', 1),
(32, 8178, 'Dạ em chào P.ĐBCL, em có nhận được mail thông báo khảo sát môn học trực tuyến. Nhưng sao em vào thì chỉ hiện \"không có dữ liệu\" vậy ạ?', '2017-12-15', 1),
(33, 11639, 'sao của em k có dữ liệu', '2017-12-17', 1),
(34, 11639, 'ghi ko có dữ liệu sao khảo sát dc', '2017-12-17', 1),
(35, 11542, 'Chưa khảo sát duoc,khong có du lieu', '2017-12-20', 1),
(36, 11541, 'Khảo sát không được dữ liệu trống', '2017-12-20', 1),
(37, 11542, 'Em không khảo sát được', '2017-12-20', 1),
(38, 11540, 'Khong khao sat duoc . Khong co du lieu khao sat', '2017-12-20', 1),
(39, 11540, 'Tại sao em chưa khảo sát được ạ?\r\n', '2017-12-20', 1),
(40, 11318, 'Em không thể khảo sát', '2017-12-22', 1),
(41, 11559, 'Chào Thầy(Cô), Thầy (Cô) giúp em, Em không có dữ liệu để khảo sát môn học. Em cảm ơn ạ.!', '2017-12-22', 1),
(42, 9776, 'Em không tìm thấy biểu mẫu khảo sát. ', '2018-03-05', 1),
(43, 3699, 'Em lên khảo sát trễ giờ đã đóng. Mong mở lại được không ạ ???', '2018-03-20', 1),
(44, 3020, 'khảo sát môn học của lớp da14ddb không cập nhật trên trang. chúng em không xác định được thời gian khảo sát. Có thể ảnh hưởng đến điểm rèn luyện', '2018-04-05', 1),
(45, 3427, 'Xin chào, của em vào khảo sát không thấy môn học,  mong thầy cô xem dùm. ', '2018-04-16', 1),
(46, 3466, 'Em tên PHẠM THỊ CẨM NHUNG, MSSV 114114126, sinh viên khoa kinh tế, luật chuyên ngành Luật khóa 2014-2018, cho em hỏi em muốn xin danh sách trích xuất khảo sát trực tuyến của HK1 2017-2018 để cộng điểm rèn luyện cho HK2 năm 2017-2018, em liên hệ trực tiếp phía phòng Đảm bảo Chất lượng để xin hay em cần phải làm gì và mang giấy tờ gì theo không ạ, em xin cảm ơn! SĐT 0982543201', '2018-04-20', 1),
(47, 4325, 'Em chi hiện có 2/5 môn khảo sát. Em thiếu môn: dinh dưỡng, sản 1va 2. Xin quý thầy cô tra lại giúp em để việc khảo sát hoàn tất.', '2018-05-09', 1),
(48, 5945, 'Chào ạ! Em đã khảo xác online xong và muốn nhận giấy xác nhận để xét điểm rèn luyện mình nhận ở đâu ạ. ', '2018-05-14', 1),
(49, 3958, 'Dạ cho em hỏi. Tại sao em không có hiện bảng khảo sát ạ', '2018-05-14', 1),
(50, 12360, '117317009@sv.tvu.edu.vn\r\n', '2018-05-17', 1),
(51, 12305, 'Giảng viên môn Tin học ứng dụng cơ bản và Đọc hiểu 2 không đúng ', '2018-05-18', 1),
(52, 10605, 'Mong quí thầy cô có thể đổi lại font được không ạ, vì font Time New Roman rất khó để coi và size chữ khá nhỏ. Quí thầy cô có thể tham khảo font: Segoe UI, Helvetica.\r\nEm xin cám ơn!', '2018-05-19', 1),
(53, 12360, 'Cho em hỏi sao hiện tại em không thể khảo sát các môn học được vậy ạ??', '2018-05-29', 1),
(54, 2938, 'Em xin chao thay co! Xin thay co coi tên cua em dum tên của em viet la MEY CHANDARA chu hk phai  la MEY CHANDA  RA\r\nEm xin cam on!', '2018-06-01', 1),
(55, 11704, 'Tại sao  em có học môn anh văn mà không có hiẹn lên lên môn để khảo sát ', '2018-06-04', 1),
(56, 4763, 'em không thấy môn cần khảo sát? tại sao vậy ạ?', '2018-06-11', 1),
(57, 10715, 'Em kính chào quý thầy cô.\r\nEm tên là Lê Qui Thanh, học lớp DA16QdL, mssv 116616062. Em xin giấy xác nhận đã khảo sát môn học online để cộng điểm rèn luyện thì em làm cách nào ạ? Em xin cảm ơn.', '2018-06-17', 1),
(58, 10521, ' em kính chào quý thầy cô lớp DA16MN môn mỹ thuật do cô Võ Thúy Hồng giảng dạy không phải cô Nguyễn Thị Hoàng Yến.\r\nkính nhờ quý thầy cô xem lại em xin cám ơn.', '2018-06-19', 1),
(59, 12920, 'Thầy (cô) cho em hỏi sao chưa có khảo sát môn học của học kì II ạ?', '2018-06-21', 1),
(60, 4768, 'Chào thầy (cô) !\r\nEm đang học gần kết thúc môn Thực hành Hóa học hữu cơ 1, Thực hành Hóa học vô cơ 1, thực hành Hóa lý 2 nhưng trang khảo sát của em không hiển thị môn học. Thầy (cô) kiểm tra giúp em để hoàn thành phiếu đánh giá khảo sát ạ', '2018-07-25', 1),
(61, 4418, 'Cho em hỏi những môn của học kỳ trước có khảo sát được không ạ?', '2018-07-28', 1),
(62, 6111, 'Không thấy dữ liệu để đánh giá môn học!!!', '2018-08-01', 1),
(63, 2926, 'E xin khảo sát lại những môn học của  học kì 2 năm học 2017-2018 vì chưa  Khảo  sát  hết  tất cả các môn  ạ\r\nNhận được  mong cho e được  khảo sát ạ', '2018-09-06', 1),
(64, 4582, 'Thưa thầy (cô) em đã thực hiện khảo sát online và có nhu cầu nhận danh sách xác nhận em đã hoàn thành thì nhận như thế nào?\r\nGmail: Khahuongnguyen1910@gmail.com\r\nSđt: 01294049049', '2018-09-14', 1),
(65, 4571, 'Lúc trước mỗi khi có khảo sát môn học là lớp trưởng thông báo em vào khảo sát ngay, nhưng học kì này em không thấy thông báo gì cả nên không khảo sát bị trừ điểm rèn luyện, hiện giờ em không thể khảo sát được nữa, em rất buồn vì có thể mất học bổng học kì này, thầy (cô) có thể mở lại khảo sát cho em được không ạ vì điểm rèn luyện chưa gửi lên khoa, xin cho e cơ hội khảo sát ạ :\'(', '2018-09-19', 1),
(66, 4571, 'Lúc trước mỗi khi có khảo sát môn học là lớp trưởng thông báo em vào khảo sát ngay, nhưng học kì này em không thấy thông báo gì cả nên không khảo sát bị trừ điểm rèn luyện, hiện giờ em không thể khảo sát được nữa, em rất buồn vì có thể mất học bổng học kì này, thầy (cô) có thể mở lại khảo sát cho em được không ạ vì điểm rèn luyện chưa gửi lên khoa, xin cho e cơ hội khảo sát ạ :\'(', '2018-09-19', 1),
(67, 4367, 'khảo sát môn học không đủ môn, chỉ hiện 2 môn thôi ạ, em muốn đánh giá hết các môn học kì rồi', '2018-09-28', 1),
(68, 4381, 'Khảo sát môn học sao chỉ có 2 môn vậy ạ', '2018-09-28', 1),
(69, 4375, 'Em chỉ khảo sát được 2 môn nhi 1 và nhi 2, các môn còn lại k hiển lên', '2018-09-28', 1),
(70, 4359, 'Tài khoản của em chỉ hiện 2 môn Nhi em đã làm xong rồi ạ! Còn những môn khác em không thể khảo sát ạ!', '2018-09-28', 1),
(71, 4315, 'Không đủ môn khảo sát', '2018-10-01', 1),
(72, 4315, 'Không đủ môn học khảo sát', '2018-10-01', 1),
(73, 4320, 'Dạ em bấm vô “Khảo sát môn học”, nhưng toàn bộ đều là “Không có dữ liệu” ạ! @.@', '2018-10-01', 1),
(74, 4312, 'Dạ cho em hỏi. Sao em không có môn học để khảo sát ạ', '2018-10-02', 1),
(75, 12360, 'Cho em hỏi. Sao em đăng nhập vào trang đảm bảo chất lượng này và vào mục Khảo Sát Môn Học mà trang vẫn hiện các môn học của Học Kì 2 Vừa rồi vậy ạ? Phía trên có ghi là khảo sát môn học của học kì 1 năm 2018-2019.', '2018-10-15', 1),
(76, 14732, 'Nào mình mới có khảo sát ạ, em tuởng học xong mỗi môn đều có khảo sát (em học đuợc PLĐC).', '2018-11-11', 1),
(77, 13005, 'sao em không thấy môn học khảo sát', '2018-11-12', 1),
(78, 5774, 'Có 4 môn hiện tại em không có đăng kí học mà có trên trang khảo sát môn học của em', '2018-11-21', 1),
(79, 10647, 'Em có 1 số thắc mắc về điểm số và kết quả học tập trên lớp thì cần liên hệ ai ạ ? Vì thầy cô chấm điểm số theo như em thấy có lẽ không phù hợp với khả năng học tập của em ạ? ', '2018-11-28', 1),
(80, 11166, 'Em thưa các thầy cô! Phần khảo sát môn học của lớp DA16XDDC Có vài môn bị trùng ạ!\r\n', '2018-12-01', 1),
(81, 14732, 'Không khảo sát được môn PLĐC, vì tháng trước e kết thúc mà gần gây mới cập nhật môn học ', '2018-12-02', 1),
(82, 11909, 'thầy ơi, em học đường lối cách mạng của cô Đầy, giáo dục thể chất 3 của cô Thanh Huyền.', '2018-12-12', 1),
(83, 14827, 'Môn Pháp luật đại cương có cần phải khảo sát môn học không ạ?\r\nTrong danh sách khảo sát của em không có môn Pháp luật đại cương thì phải làm sao?', '2018-12-18', 1),
(84, 12859, 'Em không thấy môn GDTC 3 Cầu Long của thầy Phương. ', '2018-12-24', 1),
(85, 11612, 'Có một môn học không đúng giáo viên và một môn có học nhưng không có trong danh sách khảo sát. Hy vọng quý thấy cô có thể điều chỉnh kịp thời để chúng em tiến hành khảo sát.', '2018-12-25', 1),
(86, 14008, 'Sao không có môn Những Nguyên Lí Cơ Bản Của Chủ Nghĩa Mác - Lênnin', '2018-12-28', 1),
(87, 6139, 'Kính gửi thầy, cô\r\n Em tên Khưu Tiến Phong lớp DA15TYA, vừa qua em đã hoàn thành đầy đủ khảo sát trực tuyến. Không biết làm thế nào để em có thể nhận được \"Danh sách sinh viên hoàn thành khảo sát trực tuyến\" ạ? \r\nKính mong nhận được sự giúp đỡ của quý thầy, cô. Em xin cảm ơn!', '2018-12-29', 1),
(88, 11704, 'Dạ phần khảo sát của em bị thiếu môn anh văn không chuyên 3 ,môn nguyên lí thống kê kinh tế và môn giáo dục thể chất 3 ( bơi lội) ,dạ thầy ( cô) sửa lại dùm em ạ ,em cảm ơn nhìu ạ', '2019-01-03', 1),
(89, 11704, ' Dạ phần khảo sát  của em bị thiếu môn anh van không chuyên 3 ,môn nguyên lí thống kê kinh tế voi môn giáo dục thể chất 3 ( bơi lội ) ,dạ thầy ( cô) bổ sung thêm cho em ạ ,em cảm ơn ', '2019-01-04', 1),
(90, 12273, 'Em còn thiếu 1 môn Nhập môn Ngôn ngữ học, nhờ thầy cô bổ sung vào để em làm khảo sát cho đủ ạ. Em cảm ơn !!', '2019-01-05', 1),
(91, 15097, 'em đã chuyễn ngành rồi tại sao em lên khảo sát vẫn ở ngành cũ vậy ạ em là Danh Phát Đạt lớp DA18VH từ DA18VDT chuyễn qua nhưng em lên khảo sát không đc ạ\r\n', '2019-01-07', 1),
(92, 15097, 'Em mới khảo sát đc ba môn còn các môn còn lại em không có dử liệu để khảo sát , lớp Văn Hóa Học ', '2019-01-08', 1),
(93, 15097, 'Mã số sinh viên 113818015 Danh Phát Đạt thầy coi lại giúp em ', '2019-01-08', 1),
(94, 15097, 'Em mới khảo sát đc 3 môn, còn 7 môn còn lại em chưa có dử liệu, em lớp DA18VH  tênDanh Phát Đạt MSSV 113818015 thầy chỉnh lại giúp em ', '2019-01-08', 1),
(95, 14745, 'Lớp DA18RHMA thiếu môn những nguyên lí cơ bản của chủ nghĩa Mác-lenin', '2019-01-23', 1),
(96, 14745, 'Lớp DA18RHMA thiếu môn Những nguyên lí cơ bản của chủ nghĩa Mác-lenin', '2019-01-24', 1),
(97, 14745, 'Lớp DA18RHMA thiếu môn Những nguyên lí cơ bản của chủ nghĩa Mác- Lênin', '2019-01-25', 1),
(98, 10605, 'Về việc khảo sát môn học\r\nKính thưa quý thầy (cô) trong trang khảo sát môn học của em học kì 1 2018 - 2019 đã bị thiếu môn Đọc hiểu 5 - Advanced của cô Nguyễn Thị Tuyết Nhung. \r\nMong phản hồi từ quý thầy (cô)!\r\nEm xin cám ơn.', '2019-01-31', 1),
(99, 15426, 'Em tham gia khảo sát môn học vẫn chưa nhận được mail từ hệ thống. Mong được sự giúp đỡ. Xin cám ơn', '2019-02-22', 1),
(100, 15426, 'Em tham gia khảo sát môn học vẫn chưa nhận được mail từ hệ thống. Mong được sự giúp đỡ. Xin cám ơn', '2019-02-22', 1),
(101, 4536, 'Em chào các thầy cô. \r\nHôm nay lớp e làm xét điểm rèn luyện nên đi xuất vụ khảo sát môn học ạ. E khá là buồn vì e chỉ khảo sát 5/7 môn. Không đủ 80% nên bị trừ luôn 6 đ. Tuy nhiên lỗi này không phải do em. Hôm em làm khảo sát tự nhiên đến môn thứ 5 thì hệ thống báo em đã khảo sát đủ số lượng môn học và khóa không cho em tiếp tục khảo sát. E cứ tưởng là mỗi kì mình chỉ cần khảo sát 5 môn là đủ. Lúc sau e có lên lại vài lần nhưng vẫn k vô khảo sát 2 môn còn lại được.  Thế là hết ngày hôm sau không vô được nữa.\r\nĐiều thứ 2 là thời gian khảo sát môn học ít, e và một số bạn vừa đi học vừa đi làm, khuya tụi e mới về tới nhà làm khảo sát đc 1, 2 ngày như vậy tụi e rất là mệt. Không những vậy. Một số môn thậm chí còn chưa có thời khóa biểu để học mà kêu khảo sát thì tụi e khảo sát cái gì ạ. Việc khảo sát này là để tìm hiểu tâm tư nguyện vọng của sinh viên, chất lượng giảng dạy của giảng viên, cơ sở vật chất của nhà trường hay đơn thuần chỉ là làm cho có. E hi vọng thời gian khảo sát sẽ đc kéo dài hoặc cứ để vậy đến hết kì tụi em hết môn nào tự làm môn ấy sẽ tốt hơn ạ.\r\nThứ 3. Tại sao trường lại gắt vụ 80% môn học mới được 6 điểm. Dưới thì không được điểm nào. Trong khi tính ra thời gian em loay hoay và quay đi trở lại vì lỗi web là nhiều hơn các bạn. Em hi vong năm sau nhà trường sẽ xem xét lại trừ điểm theo số môn chưa khảo sát ví dụ như trừ 1 hay 2 điểm trên 1 môn chưa khảo sát. Như vậy sẽ hợp lí hơn ạ.\r\n\r\nThứ 4. Mong các thầy cô thông cảm giúp em. E chỉ nêu ý kiến cá nhân mình vậy thôi  chứ giờ điểm cũng xét xong rồi. Hơn thua 6đ cũng vậy. E chỉ buồn vì mình đã cố gắng làm mà vẫn k đc ghi nhận dù 1%. \r\nCảm ơn thầy cô đã đọc.  E đi làm đây. Hiuhiu. \r\n', '2019-02-22', 1),
(102, 13475, 'Sai tên của giảng viên dạy môn Tiếng Việt thực hành, Vật lý đại cương, Giáo dục thể chất 2 ( bóng đá) lớp DA18CNSH', '2019-04-15', 1),
(103, 14347, 'Thay co oi, em vua lam xong Khao sat mon hoc a. Em phai lam the nao de co xac nhan tu Phong Dam bao chat luong va danh sach trich xuat tu he thong online a.', '2019-04-21', 1),
(104, 14991, 'Giảng viên môn giáo dục thể chất (võ Teakwondo) là thầy Phạm Minh Phương, không phải cô Nguyễn Thị Ánh Loan.', '2019-04-23', 1),
(105, 11976, 'Các môn học kì 2 năm 2018-2019 bị sai', '2019-05-15', 1),
(106, 14991, 'Giáo viên giảng dạy bộ môn Giáo Dục Thể Chất 2 (võ Taekwondo) là thầy Phạm Thái Phương.', '2019-06-09', 1),
(107, 14873, 'Cho em hỏi sau môn tâm lý học đại cương của thầy Nguyễn Trọng Lăng em không vào khảo sát được. ', '2019-06-14', 1),
(108, 15249, 'Em có đánh nhầp khảo sát 3 môn tư tưởng, tâm lí và sinh lí là không hài lòng do em nhìn k kĩ đã đánh nhầm. Em muốn sửa lại nhưng không đc, mong giúp đỡ ạ.\r\n', '2019-08-20', 1),
(109, 11460, 'Cho em hỏi sao e vào khảo sát không được vậy', '2019-09-10', 1),
(110, 12640, 'em muốn khảo sát môn học nhưng mà hết hạn thì phải làm sao ạ?', '2019-09-10', 1),
(111, 15552, 'Thực hiện khảo sát xong', '2019-09-13', 1),
(112, 15239, 'Xin chào!\r\nKhảo sát môn học của tôi thiếu môn khảo sát', '2019-12-11', 1),
(113, 15146, 'E bị thiếu 3 môn. Tổ chức y tế, huyết học cơ sở và giải phẫu. Cô coi lại giùm em', '2019-12-12', 1),
(114, 10229, 'Tại sao đã kết thúc hết tất cả các môn trong học kì mà vẩn chưa được khảo sát môn học trực tuyến.', '2019-12-25', 1),
(115, 14207, 'Mục Khảo sát môn học của em bị thiếu 1 môn ', '2020-01-09', 1),
(116, 17275, 'Em vẫn chưa khảo sát hết các môn HKI mà sao em đăng nhập vô lại hiện HKII mà không hiện lại HK1 ạ???', '2020-05-08', 1),
(117, 12664, 'Em đã khảo sát môn học nhưng chưa nhận được mail xác nhận ạ', '2020-05-11', 1),
(118, 13658, 'Thầy cô cho em hỏi là sao tài khoản của em chưa hiện môn học khảo sát của học kỳ 2 năm học 2019_2020 ?', '2020-05-13', 1),
(119, 16442, 'Thầy ơi, em là Dương Thị Diễm lớp DA19NNAD . Em xin bảng danh sách lớp em đã khảo sát online ạ ', '2020-05-18', 1),
(120, 15240, 'Trường hợp của em thiếu rất nhiều môn khảo sát so với các bạn ạ', '2020-05-21', 1),
(121, 15240, 'Trường hợp của các bạn sinh viên 116018111 , 116018092, 116018095', '2020-05-21', 1),
(122, 15240, 'Trường hợp các bạn sinh viên 116018111, 116018092, 116018095 cũng bị mất rất nhiều môn khảo sát môn học ạ', '2020-05-21', 1),
(123, 15994, 'em xin chào thầy cô ạ... em tên là Nguyễn Thị Ngọc Mai \r\nngành công nghệ kỹ thuật hóa học\r\ndo tuần trước em chưa khảo sat môn học nên hôm nay em đã khảo sát \r\nem rất mong thầy cô cho em xin danh sách bổ sung ạ..\r\nem cảm ơn ạ', '2020-06-01', 1),
(124, 17360, 'Em không làm khảo sát được', '2020-06-15', 1),
(125, 11193, 'Dạ cho em hỏi có còn khảo sát môn học học kỳ 1 năm 2019-2020 được không ạ', '2020-06-18', 1),
(126, 14888, 'Học kì này không cho khảo sát môn học ak', '2020-06-20', 1),
(127, 17636, 'Cho em hỏi làm sao để nhận danh sách SV thực hiện khảo sát môn học ạ', '2020-07-04', 1),
(128, 12109, 'Khảo sát học kì 1 năm học 2019- 20120', '2020-07-06', 1),
(129, 16968, 'Em xin làm phiền. Cho em hỏi em cần danh sách trích từ hệ thống online để xét điểm rèn luyện thì làm như thế nào?  Em xin cảm ơn? ', '2020-07-07', 1),
(130, 17271, 'Xin file khảo sát', '2020-07-11', 1),
(131, 15426, 'Chưa kết thúc chương trình học của học kỳ nên còn nhiều bạn chưa tham gia khảo sát môn học online nhưng hiện tại đã đóng cổng khảo sát, và vì cũng không biết thời gian đóng khảo sát... Học kỳ năm 2 năm 2019 2020 có thể mở lại cổng khảo sát được không ạ', '2020-08-22', 1),
(132, 15363, 'Em sinh viên Nguyễn Đức Minh lớp da18ykc\r\nMssv 116018130 không khảo sát được ạ', '2020-09-16', 1),
(133, 16842, 'Môn học trên hệ thống khảo sát của em chỉ có 1 môn thôi ạ, trong khi các bạn khác đã có tới 5-6 môn rồi ạ', '2020-10-26', 1),
(134, 16848, 'Yêu cầu nhà trường thêm môn học khảo sát cho em ạ', '2020-10-27', 1),
(135, 16855, 'Bạn cùng lớp có 6 môn khảo sát, nhưng em chỉ có 2 môn khao sát ạ', '2020-10-28', 1),
(136, 12175, 'Đánh nhầm môn khảo sát đổi như thế nào ạ', '2020-12-21', 1),
(137, 12175, 'Đánh nhầm môn khảo sát đổi như thế nào ạ', '2020-12-21', 1),
(138, 12175, 'Đánh nhầm môn khảo sát đổi như thế nào ạ', '2020-12-21', 1),
(139, 12175, 'Đánh nhầm môn khảo sát đổi như thế nào ạ', '2020-12-21', 1),
(140, 12175, 'Đánh nhầm môn khảo sát đổi như thế nào ạ', '2020-12-21', 1),
(141, 12175, 'Đánh nhầm môn khảo sát đổi như thế nào ạ', '2020-12-21', 1),
(142, 12664, 'Cho em hỏi sao em vào không thấy các môn khảo sát hk1 ạ', '2021-01-04', 1),
(143, 17276, 'Thưa thầy/cô, \r\nEm Trương Hoàng Bích Kỳ, lớp DA19XYHB, mssv 115319106\r\nEm học bên ngành Xét nghiệm y học và không có đăng ký môn Địa chất công trình trong học kỳ 1 (2020-2021). Nhưng lại xuất hiện trong phần khảo sát môn học của em, em đã kiểm tra lại tkb bên trang ttsv rồi và không có môn này.\r\nMong thầy/cô kiểm tra giúp em.\r\nEm cảm ơn.', '2021-01-10', 1),
(144, 18633, 'dạ em lỡ bấm nhầm khi chưa khảo sát xong và muốn đổi kết quả khảo sát lại ạ\r\n', '2021-03-02', 1),
(145, 18633, 'Dạ khảo sát môn kinh tế vi mô của em chưa làm xong mà đã bị khóa lại. Em đang làm thì nó tự thoát trang luôn. Khóa cả khảo sát của em. Vậy em cần làm thế nào để hoàn thành khảo sát của em ạ', '2021-03-18', 1),
(146, 19900, 'DA20YKH', '2021-03-22', 1),
(147, 19889, 'em đăng nhập được...nhưng khi vào mục KHẢO SÁT MÔN HỌC thì không thực hiện khảo sát được...không hiển thị các phần để em chọn', '2021-03-26', 1),
(148, 19554, 'Em kính chào Quý Thầy Cô\r\nEm học lớp DA20YKB, học kỳ rồi em được miễn các môn cơ bản chỉ học môn Giải phẫu 1. Em có đăng nhập để tham gia khảo sát môn hoc nhưng không khảo sát được.\r\nKính mong Quý Thầy Cô xem xét, kiểm tra lại ạ\r\nEm xin cám ơn', '2021-03-27', 1),
(149, 19849, 'Em tên là Trần Trung Nguyên đầu năm em đã chuyển qua lớp DA20YKC nhưng danh sách khảo sát môn học vẫn trong lớp DA20YKG ạ.\r\nMong thầy/cô sửa thông tin lớp của em từ DA20YKG sang DA20YKC ạ', '2021-03-28', 1),
(150, 19726, 'minhtrung.cala@gmail.com', '2021-04-03', 1),
(151, 19462, 'Thầy/cô ơi sao em tính dow lại danh sách khảo sát HK I không được giờ chỉ hiện HK II không ak', '2021-04-22', 1),
(152, 19040, 'Em xuất danh sách kh được ạ', '2021-05-06', 1);

-- --------------------------------------------------------

--
-- Table structure for table `kemail_queue`
--

CREATE TABLE `kemail_queue` (
  `id` int(15) NOT NULL,
  `priority` int(1) NOT NULL DEFAULT '5',
  `time` timestamp NOT NULL,
  `from` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `to` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `subject` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `body` longtext COLLATE utf8_unicode_ci NOT NULL,
  `additional_headers` longtext COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `title` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `author` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `view` int(11) NOT NULL,
  `slug` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `public` tinyint(4) DEFAULT NULL,
  `level` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `type`, `title`, `date`, `author`, `description`, `content`, `view`, `slug`, `public`, `level`) VALUES
(1, 1, 'Cập nhật thông tin', '23/09/2015 23:42:00', 'Admin', 'Cập nhật thông tin cá nhân như số điện thoại và email để có thể nhận thông tin tự động từ hệ thống khảo sát môn học, và được tư vấn từ cán bộ Phòng đảm bảo chất lượng.', '<p>fhsd;lfjks;&agrave;;a</p>\r\n<p>fasd;lfja;kskfj</p>\r\n<p>fasd;klfjasd;lfj</p>\r\n<p style=\"text-align: center;\">a<em>fsd;klfjas;lfja;ljf</em></p>\r\n<p><img src=\"/khaosat2/filemanager/source/dtn.jpg\" alt=\"dtn\" /></p>', 1, 'bv-1', 1, 0),
(2, 1, 'Bài viết test 2', '21/09/2021 15:29:45', '', 'Cập nhật thông tin cá nhân như số điện thoại và email để có thể nhận thông tin tự động từ hệ thống khảo sát môn học, và được tư vấn từ cán bộ Phòng đảm bảo chất lượng.', '<p>fdasf</p>', 0, 'bai-viet-test-2', 1, 0),
(8, 1, 'Hướng dẫn khảo sát trực tuyến', '21/03/2021 11:07:16', 'Admin', ' Hướng dẫn sinh viên chi tiết các bước thực hiện khảo sát môn học trực tuyến trên hệ thống khảo sát môn học trực tuyến của Trường Đại học Trà Vinh.', '<a href=\"https://tvusv-my.sharepoint.com/:p:/g/personal/nqkhanh_tvu_edu_vn/EQLuaRMbJ1lOrRL9cUsqKPQBdWysLUIsU-HzTk39sWEGHQ?e=zUKRJ5\" target=\"_blank\">https://tvusv-my.sharepoint.com/:p:/g/personal/nqkhanh_tvu_edu_vn/EQLuaRMbJ1lOrRL9cUsqKPQBdWysLUIsU-HzTk39sWEGHQ?e=zUKRJ5</a><br />', 1460, 'bv-2', 1, 0),
(13, 2, 'Hướng dẫn giảng viên xem và in kết quả khảo sát môn học trực tuyến', '29/03/2021 07:18:38', 'Admin', 'Hướng dẫn giảng viên xem và in kết quả khảo sát môn học trực tuyến', 'Quý Thầy/Cô vui lòng tải tại đây:&nbsp;<a href=\"https://drive.google.com/file/d/1LijB7_XRBfpAEGzWpeTow3Se7CGlAtrc/view?usp=sharing\" target=\"_blank\">Hướng dẫn giảng viên xem và in kết quả khảo sát môn học trực tuyến</a>', 0, 'bv-3', 1, 0),
(14, 1, 'Bài viết test', '21/09/2021 14:04:12', 'DBCL', 'tóm tắt', '<p><img src=\"/ks20/filemanager/source/219437169_1249215218865129_5866755427097168775_n%20(1).jpg\" alt=\"\" width=\"444\" height=\"960\" /></p>', 0, 'bai-vit-test', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pcounter_by_day`
--

CREATE TABLE `pcounter_by_day` (
  `id` int(11) NOT NULL,
  `day` date NOT NULL,
  `user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `pcounter_by_day`
--

INSERT INTO `pcounter_by_day` (`id`, `day`, `user`) VALUES
(130, '2022-12-01', 0),
(131, '2022-12-03', 0),
(132, '2022-12-09', 0),
(133, '2023-02-01', 0),
(134, '2023-02-02', 1),
(135, '2023-02-09', 0),
(136, '2023-02-10', 1),
(137, '2023-02-12', 0);

-- --------------------------------------------------------

--
-- Table structure for table `pcounter_save`
--

CREATE TABLE `pcounter_save` (
  `save_name` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `save_value` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `pcounter_save`
--

INSERT INTO `pcounter_save` (`save_name`, `save_value`) VALUES
('counter', 9),
('day_time', 2459989),
('max_count', 1),
('max_time', 1669870800),
('yesterday', 0);

-- --------------------------------------------------------

--
-- Table structure for table `pcounter_users`
--

CREATE TABLE `pcounter_users` (
  `user_ip` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_time` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `pcounter_users`
--

INSERT INTO `pcounter_users` (`user_ip`, `user_time`) VALUES
('f528764d624db129b32c21fbca0cb8d6', 1676254224);

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `id` int(11) NOT NULL,
  `room_parent` int(11) NOT NULL,
  `room_code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `room_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`id`, `room_parent`, `room_code`, `room_name`) VALUES
(266, 105, 'K-01', 'Khoa Y - Dược'),
(267, 105, 'K-02', 'Khoa Kinh tế, Luật'),
(268, 105, 'K-03', 'Khoa Ngoại ngữ'),
(269, 105, 'K-04', 'Khoa Kỹ thuật và Công nghệ'),
(270, 105, 'K-05', 'Khoa Nông nghiệp - Thủy sản'),
(271, 105, 'K-06', 'Khoa Ngôn ngữ - Văn hóa - Nghệ thuật - Khmer Nam bộ'),
(272, 105, 'K-07', 'Khoa Hóa học Ứng dụng'),
(273, 105, 'K-08', 'Khoa Sư phạm'),
(274, 105, 'K-09', 'Khoa Quản lý nhà nước, Quản trị văn phòng'),
(275, 105, 'K-10', 'Khoa Khoa học cơ bản'),
(276, 105, 'K-11', 'Khoa Lý luận chính trị'),
(277, 105, 'K-12', 'Khoa Răng Hàm Mặt'),
(278, 107, 'TT-01', 'Trung tâm dịch vụ việc làm'),
(279, 107, 'TT-02', 'Trung tâm Giáo dục quốc phòng & An ninh ĐHTV'),
(280, 108, 'P-01', 'Phòng Đào tạo Sau đại học'),
(281, 108, 'P-02', 'Phòng Đào tạo'),
(282, 108, 'P-03', 'Phòng Công tác Sinh viên - Học sinh'),
(283, 108, 'P-04', 'Phòng Đảm bảo chất lượng'),
(284, 108, 'P-05', 'Phòng Khảo thí'),
(285, 108, 'P-06', 'Phòng Hành chính Tổng hợp'),
(286, 108, 'P-07', 'Phòng Hợp tác Quốc tế và Xúc tiến dự án'),
(287, 108, 'P-08', 'Phòng Kế hoạch Tài vụ'),
(288, 108, 'P-09', 'Phòng Khoa học Công nghệ'),
(289, 108, 'P-10', 'Phòng Quản trị thiết bị'),
(290, 108, 'P-11', 'Phòng Tổ chức nhân sự'),
(291, 108, 'P-12', 'Phòng Truyền thông & Quảng bá cộng đồng'),
(292, 108, 'P-13', 'Phòng Thanh tra Pháp chế'),
(293, 108, 'P-14', 'Phòng Công nghệ thông tin'),
(294, 109, 'B-01', 'Ban Quản lý Ký túc xá'),
(295, 107, 'TT-03', 'Trung tâm Học liệu - Phát triển Dạy & Học');

-- --------------------------------------------------------

--
-- Table structure for table `room_parent`
--

CREATE TABLE `room_parent` (
  `id` int(11) NOT NULL,
  `room_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `room_parent`
--

INSERT INTO `room_parent` (`id`, `room_name`) VALUES
(105, 'Khoa'),
(106, 'Viện'),
(107, 'Trung tâm'),
(108, 'Phòng'),
(109, 'Ban');

-- --------------------------------------------------------

--
-- Table structure for table `setting`
--

CREATE TABLE `setting` (
  `id` int(11) NOT NULL,
  `lock_system` tinyint(1) NOT NULL,
  `current_course` int(11) NOT NULL,
  `old_course` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `setting`
--

INSERT INTO `setting` (`id`, `lock_system`, `current_course`, `old_course`) VALUES
(1, 0, 12, 11);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `confirmation_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `superadmin` smallint(6) DEFAULT '0',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `registration_ip` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bind_to_ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email_confirmed` smallint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `auth_key`, `password_hash`, `confirmation_token`, `status`, `superadmin`, `created_at`, `updated_at`, `registration_ip`, `bind_to_ip`, `email`, `email_confirmed`) VALUES
(1, 'dbcl', 'w1FKYMqLBHfZnaj3PLvg8JyqaEPWNgbV', '$2y$13$.NV9wJxwjt/S/gSWNx4l5Ock/BvoYByhSKOO7eeQPHj/SxZKchUwK', NULL, 1, 1, 1627264803, 1676129634, NULL, '', 'khucthuydu.2801@gmail.com', 0),
(2, 'user01', 'bXasRfXUyTn5e7W76WZyhxY6cy4Iu9sL', '$2y$13$cmN4QA302YKD5IEwcP0Xwu.bNZnommEYv6acLULonEB1orjg2jrJC', NULL, 1, 0, 1627353830, 1671282241, '127.0.0.1', '', 'travinhfashion@gmail.com', 0),
(4, 'user02', '3RKXvDTp1cNGyzpKlGpmUnSzUU8Qu2D_', '$2y$13$ESEs505x5lqdtwkIIFPg2Oiwajz58xlkZWavL9vMEGfx0tFt7bptS', NULL, 1, 0, 1669222661, 1676254213, '127.0.0.1', '', '', 0),
(5, 'quantri@gmail.com', 'geTlmTYrj3LeD3tf5DzznAqKO4jwCQEe', '$2y$13$nldLE2U8QWujfyheKnwmaexWRUU7IFpQEwLCMqf3fkc3x4YsunZ2.', NULL, 1, 0, 1671544721, 1671544721, '127.0.0.1', '', 'quantri@gmail.com', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_profile`
--

CREATE TABLE `user_profile` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `position` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `room_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user_profile`
--

INSERT INTO `user_profile` (`id`, `name`, `phone`, `address`, `position`, `room_id`) VALUES
(1, 'Admin', '', '', '', 267),
(2, 'Nguyễn Văn A', '037', 'Càng Long', '', 270),
(4, 'Nguyễn văn a', '0123', 'trà vinh', 'nhân viên', 267),
(5, 'Quan tri', '', '', '', 266);

-- --------------------------------------------------------

--
-- Table structure for table `user_visit_log`
--

CREATE TABLE `user_visit_log` (
  `id` int(11) NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `language` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `user_agent` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `visit_time` int(11) NOT NULL,
  `browser` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `os` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user_visit_log`
--

INSERT INTO `user_visit_log` (`id`, `token`, `ip`, `language`, `user_agent`, `user_id`, `visit_time`, `browser`, `os`) VALUES
(104, '63899684ead4f', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36', 2, 1669961348, 'Chrome', 'Windows'),
(105, '63899794aa1e6', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36 Edg/107.0.1418.62', 4, 1669961620, 'Chrome', 'Windows'),
(106, '638d955ea23b4', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36', 1, 1670223198, 'Chrome', 'Windows'),
(107, '639331c34a125', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', 1, 1670590915, 'Chrome', 'Windows'),
(108, '6395ef700cbda', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', 1, 1670770544, 'Chrome', 'Windows'),
(109, '63a1bf4ac874a', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', 1, 1671544650, 'Chrome', 'Windows'),
(110, '63a3ab1166107', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', 1, 1671670545, 'Chrome', 'Windows'),
(111, '63db0a0086d78', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36', 1, 1675299328, 'Chrome', 'Windows'),
(112, '63dc67a352bab', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36', 1, 1675388835, 'Chrome', 'Windows'),
(113, '63dc6ebb32948', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36 Edg/109.0.1518.70', 4, 1675390651, 'Chrome', 'Windows'),
(114, '63e6032122c32', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36', 1, 1676018465, 'Chrome', 'Windows'),
(115, '63e603bccd2bd', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36', 1, 1676018620, 'Chrome', 'Windows'),
(116, '63e6dd08539c7', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36', 1, 1676074248, 'Chrome', 'Windows'),
(117, '63e99c103a3e3', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36', 4, 1676254224, 'Chrome', 'Windows'),
(118, '63e99cdab19ee', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36', 1, 1676254426, 'Chrome', 'Windows');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auth_assignment`
--
ALTER TABLE `auth_assignment`
  ADD PRIMARY KEY (`item_name`,`user_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `auth_item`
--
ALTER TABLE `auth_item`
  ADD PRIMARY KEY (`name`),
  ADD KEY `rule_name` (`rule_name`),
  ADD KEY `idx-auth_item-type` (`type`),
  ADD KEY `fk_auth_item_group_code` (`group_code`);

--
-- Indexes for table `auth_item_child`
--
ALTER TABLE `auth_item_child`
  ADD PRIMARY KEY (`parent`,`child`),
  ADD KEY `child` (`child`);

--
-- Indexes for table `auth_item_group`
--
ALTER TABLE `auth_item_group`
  ADD PRIMARY KEY (`code`);

--
-- Indexes for table `auth_rule`
--
ALTER TABLE `auth_rule`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `bm_docgroup`
--
ALTER TABLE `bm_docgroup`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_iso` (`id_iso`);

--
-- Indexes for table `bm_docs`
--
ALTER TABLE `bm_docs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_type` (`id_type`),
  ADD KEY `id_group` (`id_group`);

--
-- Indexes for table `bm_doctype`
--
ALTER TABLE `bm_doctype`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bm_document`
--
ALTER TABLE `bm_document`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_working` (`id_working`);

--
-- Indexes for table `bm_examination`
--
ALTER TABLE `bm_examination`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_iso` (`id_iso`);

--
-- Indexes for table `bm_iso`
--
ALTER TABLE `bm_iso`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bm_team_member`
--
ALTER TABLE `bm_team_member`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_team` (`id_working`),
  ADD KEY `id_position` (`id_position`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `bm_team_postion`
--
ALTER TABLE `bm_team_postion`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bm_template`
--
ALTER TABLE `bm_template`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bm_working`
--
ALTER TABLE `bm_working`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_examination` (`id_examination`),
  ADD KEY `id_room` (`id_room`);

--
-- Indexes for table `bm_working_files`
--
ALTER TABLE `bm_working_files`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_working` (`id_working`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kemail_queue`
--
ALTER TABLE `kemail_queue`
  ADD PRIMARY KEY (`id`),
  ADD KEY `priority` (`priority`),
  ADD KEY `time` (`time`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`),
  ADD KEY `type` (`type`);

--
-- Indexes for table `pcounter_by_day`
--
ALTER TABLE `pcounter_by_day`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pcounter_save`
--
ALTER TABLE `pcounter_save`
  ADD PRIMARY KEY (`save_name`);

--
-- Indexes for table `pcounter_users`
--
ALTER TABLE `pcounter_users`
  ADD PRIMARY KEY (`user_ip`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`id`),
  ADD KEY `room_parent` (`room_parent`);

--
-- Indexes for table `room_parent`
--
ALTER TABLE `room_parent`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `setting`
--
ALTER TABLE `setting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_profile`
--
ALTER TABLE `user_profile`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_visit_log`
--
ALTER TABLE `user_visit_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bm_docgroup`
--
ALTER TABLE `bm_docgroup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `bm_docs`
--
ALTER TABLE `bm_docs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `bm_doctype`
--
ALTER TABLE `bm_doctype`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bm_document`
--
ALTER TABLE `bm_document`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `bm_examination`
--
ALTER TABLE `bm_examination`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bm_iso`
--
ALTER TABLE `bm_iso`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `bm_team_member`
--
ALTER TABLE `bm_team_member`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `bm_team_postion`
--
ALTER TABLE `bm_team_postion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `bm_template`
--
ALTER TABLE `bm_template`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `bm_working`
--
ALTER TABLE `bm_working`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `bm_working_files`
--
ALTER TABLE `bm_working_files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=153;

--
-- AUTO_INCREMENT for table `kemail_queue`
--
ALTER TABLE `kemail_queue`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `pcounter_by_day`
--
ALTER TABLE `pcounter_by_day`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=138;

--
-- AUTO_INCREMENT for table `room`
--
ALTER TABLE `room`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=296;

--
-- AUTO_INCREMENT for table `room_parent`
--
ALTER TABLE `room_parent`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=110;

--
-- AUTO_INCREMENT for table `setting`
--
ALTER TABLE `setting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user_profile`
--
ALTER TABLE `user_profile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user_visit_log`
--
ALTER TABLE `user_visit_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=119;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_assignment`
--
ALTER TABLE `auth_assignment`
  ADD CONSTRAINT `auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `auth_assignment_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `auth_item`
--
ALTER TABLE `auth_item`
  ADD CONSTRAINT `auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_auth_item_group_code` FOREIGN KEY (`group_code`) REFERENCES `auth_item_group` (`code`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `auth_item_child`
--
ALTER TABLE `auth_item_child`
  ADD CONSTRAINT `auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `bm_docgroup`
--
ALTER TABLE `bm_docgroup`
  ADD CONSTRAINT `bm_docgroup_ibfk_1` FOREIGN KEY (`id_iso`) REFERENCES `bm_iso` (`id`);

--
-- Constraints for table `bm_docs`
--
ALTER TABLE `bm_docs`
  ADD CONSTRAINT `bm_docs_ibfk_1` FOREIGN KEY (`id_group`) REFERENCES `bm_docgroup` (`id`),
  ADD CONSTRAINT `bm_docs_ibfk_2` FOREIGN KEY (`id_type`) REFERENCES `bm_doctype` (`id`);

--
-- Constraints for table `bm_document`
--
ALTER TABLE `bm_document`
  ADD CONSTRAINT `bm_document_ibfk_1` FOREIGN KEY (`id_working`) REFERENCES `bm_working` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `bm_examination`
--
ALTER TABLE `bm_examination`
  ADD CONSTRAINT `bm_examination_ibfk_1` FOREIGN KEY (`id_iso`) REFERENCES `bm_iso` (`id`);

--
-- Constraints for table `bm_team_member`
--
ALTER TABLE `bm_team_member`
  ADD CONSTRAINT `bm_team_member_ibfk_1` FOREIGN KEY (`id_working`) REFERENCES `bm_working` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `bm_team_member_ibfk_2` FOREIGN KEY (`id_position`) REFERENCES `bm_team_postion` (`id`);

--
-- Constraints for table `bm_working`
--
ALTER TABLE `bm_working`
  ADD CONSTRAINT `bm_working_ibfk_1` FOREIGN KEY (`id_examination`) REFERENCES `bm_examination` (`id`),
  ADD CONSTRAINT `bm_working_ibfk_2` FOREIGN KEY (`id_room`) REFERENCES `room` (`id`);

--
-- Constraints for table `bm_working_files`
--
ALTER TABLE `bm_working_files`
  ADD CONSTRAINT `bm_working_files_ibfk_1` FOREIGN KEY (`id_working`) REFERENCES `bm_working` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `room`
--
ALTER TABLE `room`
  ADD CONSTRAINT `room_ibfk_1` FOREIGN KEY (`room_parent`) REFERENCES `room_parent` (`id`);

--
-- Constraints for table `user_visit_log`
--
ALTER TABLE `user_visit_log`
  ADD CONSTRAINT `user_visit_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
